export async function onRequestPost({ request, env }) {
  let data;
  try { data = await request.json(); } catch { return json({ error: "Solicitud no válida." }, 400); }
  const required = ["name", "phone", "petName", "petType", "service", "date", "time"];
  for (const field of required) {
    if (typeof data[field] !== "string" || !data[field].trim()) return json({ error: "Completa todos los campos obligatorios." }, 400);
  }
  if (data.name.length > 90 || data.phone.length > 25 || data.petName.length > 70 || (data.notes || "").length > 1000) {
    return json({ error: "Revisa la longitud de los campos e inténtalo nuevamente." }, 400);
  }
  if (!/^[0-9+() -]{7,20}$/.test(data.phone)) return json({ error: "Ingresa un número de WhatsApp válido." }, 400);
  const date = new Date(`${data.date}T12:00:00`);
  if (Number.isNaN(date.getTime()) || data.date < new Date().toISOString().slice(0, 10)) return json({ error: "Selecciona una fecha válida." }, 400);
  const id = crypto.randomUUID();
  const reservation = {
    id, name: data.name.trim(), phone: data.phone.trim(), pet_name: data.petName.trim(),
    pet_type: data.petType, service: data.service, preferred_date: data.date,
    preferred_time: data.time, notes: (data.notes || "").trim().slice(0,1000),
    created_at: new Date().toISOString()
  };
  if (env.DB) {
    try {
      await env.DB.prepare(`INSERT INTO reservations
        (id, name, phone, pet_name, pet_type, service, preferred_date, preferred_time, notes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .bind(reservation.id, reservation.name, reservation.phone, reservation.pet_name,
          reservation.pet_type, reservation.service, reservation.preferred_date,
          reservation.preferred_time, reservation.notes, reservation.created_at).run();
    } catch (error) {
      console.error("D1 insert error:", error);
      return json({ error: "No pudimos guardar tu solicitud. Inténtalo más tarde o contáctanos por WhatsApp." }, 500);
    }
  } else {
    // Sin D1, la solicitud se valida pero no queda guardada en una base de datos.
    console.log("Reservation received (D1 not configured):", { ...reservation, phone: "[hidden]" });
  }
  return json({
    ok: true,
    id,
    message: env.DB
      ? "¡Solicitud guardada! Nos pondremos en contacto contigo para confirmar los detalles."
      : "¡Solicitud recibida! Para asegurarte de que podamos coordinarla, escríbenos también por WhatsApp. (La base de datos aún no está conectada.)"
  }, 201);
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}
