const $ = (selector) => document.querySelector(selector);
const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "×" : "☰";
});
mainNav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  mainNav.classList.remove("open"); menuToggle.setAttribute("aria-expanded","false"); menuToggle.textContent="☰";
}));

const dateInput = $("#bookingDate");
const today = new Date();
dateInput.min = new Date(today.getTime() - today.getTimezoneOffset()*60000).toISOString().slice(0,10);
document.querySelectorAll("[data-service]").forEach(link => link.addEventListener("click", () => {
  const service = link.dataset.service;
  if (service) $("#serviceSelect").value = service;
}));

const bookingForm = $("#bookingForm");
const formStatus = $("#formStatus");
bookingForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!bookingForm.reportValidity()) return;
  const submit = bookingForm.querySelector('button[type="submit"]');
  const original = submit.innerHTML;
  submit.disabled = true; submit.textContent = "Enviando solicitud...";
  formStatus.className = "form-status";
  const payload = Object.fromEntries(new FormData(bookingForm).entries());
  try {
    const response = await fetch("/api/reservations", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "No se pudo enviar la solicitud.");
    formStatus.className = "form-status success";
    formStatus.textContent = result.message || "¡Solicitud enviada! Nos pondremos en contacto contigo.";
    bookingForm.reset();
  } catch (error) {
    formStatus.className = "form-status error";
    formStatus.textContent = error.message || "No se pudo conectar. Intenta nuevamente o escríbenos por WhatsApp.";
  } finally {
    submit.disabled = false; submit.innerHTML = original;
  }
});

const chatPanel = $("#chatPanel"), chatLauncher = $("#chatLauncher"), chatClose = $("#chatClose");
function toggleChat(open) {
  chatPanel.hidden = !open;
  chatLauncher.setAttribute("aria-expanded", String(open));
  if (open) $("#chatInput").focus();
}
chatLauncher.addEventListener("click", () => toggleChat(chatPanel.hidden));
chatClose.addEventListener("click", () => toggleChat(false));
const messages = $("#chatMessages");
function addMessage(text, who) {
  const bubble = document.createElement("div");
  bubble.className = `chat-bubble ${who}`;
  bubble.textContent = text;
  messages.appendChild(bubble); messages.scrollTop = messages.scrollHeight;
  return bubble;
}
async function sendChat(text) {
  const question = text.trim();
  if (!question) return;
  document.querySelector(".quick-questions")?.remove();
  addMessage(question, "user");
  const loading = addMessage("Estoy pensando...", "bot");
  try {
    const response = await fetch("/api/chat", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:question})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "No pude responder en este momento.");
    loading.textContent = data.reply;
  } catch (error) {
    loading.textContent = `${error.message} Puedes escribirnos por WhatsApp para recibir ayuda.`;
    const wa = document.createElement("a");
    wa.href = "https://wa.me/51900000000?text=" + encodeURIComponent("Hola, necesito ayuda con Amiguito Peludito.");
    wa.target = "_blank"; wa.rel = "noopener"; wa.className = "chat-bubble bot"; wa.textContent = "Abrir WhatsApp ↗";
    messages.appendChild(wa);
  }
  messages.scrollTop = messages.scrollHeight;
}
$("#chatForm").addEventListener("submit", e => {
  e.preventDefault(); const input=$("#chatInput"); const value=input.value; input.value=""; sendChat(value);
});
document.querySelectorAll(".quick-questions button").forEach(button => button.addEventListener("click", () => sendChat(button.dataset.question)));
